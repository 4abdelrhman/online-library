from django.shortcuts import render, redirect, get_object_or_404
from .models import Book
from .forms import BookForm

def admin_page(request):
    books = Book.objects.all()
    add_form = BookForm()
    return render(request, 'admin.html', {
        'books': books,
        'add_form': add_form,
    })

def add_book(request):
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('admin_page')
    else:
        form = BookForm()
    return render(request, 'admin.html', {'add_form': form})


def edit_book(request, book_id):
    book = get_object_or_404(Book, pk=book_id)
    if request.method == 'POST':
        form = BookForm(request.POST, instance=book)
        if form.is_valid():
            form.save()
        return redirect('admin_page')

def delete_book(request, book_id):
    book = get_object_or_404(Book, pk=book_id)
    if request.method == 'POST':
        book.delete()
    return redirect('admin_page')
