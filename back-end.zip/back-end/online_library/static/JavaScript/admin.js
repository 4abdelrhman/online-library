function addBook() {
  document.getElementById('add-book-popup').style.display = 'block';
}

function closeAddBookPopup() {
  document.getElementById('add-book-popup').style.display = 'none';
}

function deleteBook(button) {
  const bookElement = button.closest('.book');
  const bookId = bookElement.getAttribute('data-id');
  const form = document.getElementById(`delete-form-${bookId}`);
  form.submit(); // Submit the form to delete the book
}

function editBook(button) {
  const bookCard = button.closest('.book');

  const bookId = bookCard.getAttribute('data-id');
  const title = bookCard.querySelector('h2').innerText;
  const author = bookCard.querySelector('.auther').innerText;
  const description = bookCard.querySelector('.description').innerText;
  const cover = bookCard.querySelector('.book-cover').src;

  // Fill the popup form
  document.getElementById('edit-book-id').value = bookId;
  document.getElementById('edit-title').value = title;
  document.getElementById('edit-author').value = author;
  document.getElementById('edit-description').value = description;
  document.getElementById('edit-cover-url').value = cover;

  // Show the popup
  document.getElementById('edit-popup').style.display = 'block';
}

function closePopup() {
  document.getElementById('edit-popup').style.display = 'none';
}
